package com.example.myapplication

class trigger_page {

}